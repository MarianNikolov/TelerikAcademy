# Development Tools Homework

1.  Research and use the following tools in one of your projects and provide some output or screenshots for each tool to prove that you actually used the tools
    *   One source control system (TFS, SVN or Git)
    *   log4net
    *   StyleCop or JustCode
    *   JustDecompile or ILSpy
    *   Sandcastle or Doxygen
    *   Some obfuscation tool of your choice
1.  Write a simple T4 template of your choice
1.  If you haven't yet, upload all your Telerik Academy homework projects in GitHub and provide a public link to the repository.
    *   This homework is not expected to be anonymous
