﻿namespace SchoolSystem.Models
{
    public enum Subjct
    {
        Bulgarian,
        English,
        Math,
        Programming,
    }
}
